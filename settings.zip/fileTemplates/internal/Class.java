#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
/**
 * 描述：${DESCRIPTION}
 * 
 * @author (♑)₭₥₇™ 
 * @since JDK_8
 * @date ${DATE} ${TIME}
*/
#parse("File Header.java")
public class ${NAME} {

    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(${NAME}.class); 

}
