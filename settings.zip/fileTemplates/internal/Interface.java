#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * 描述：${DESCRIPTION}
 * 
 * @author (♑)₭₥₇™ 
 * @since JDK_8
 * @date ${DATE} ${TIME}
*/
public interface ${NAME} {

}
