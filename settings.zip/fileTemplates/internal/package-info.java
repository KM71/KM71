/**
 * 描述：${DESCRIPTION}
 * 
 * @author (♑)₭₥₇™ 
 * @since JDK_8
 * @date ${DATE} ${TIME}
*/
#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end